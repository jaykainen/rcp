export default function CopyMe() {
  return (
    <section className="mt-4">
      <h2 className="text-5xl text-center font-bold">Copy Me</h2>
      <div className="mt-4"></div>
    </section>
  )
}
